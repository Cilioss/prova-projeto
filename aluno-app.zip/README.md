# Projeto Angular - Lista e Cadastro de Alunos

Este projeto foi gerado com [Angular CLI](https://github.com/angular/angular-cli) e contém duas telas:

- Lista de alunos
- Cadastro de alunos

Os dados são salvos no `localStorage`.

## Rodando o projeto

```bash
npm install
ng serve
```
